﻿using System;
using System.Threading.Tasks;

namespace Listings
{
    class Item_28 //Web Service
    {
        static void XMain(string[] args)
        {
            //TAREFA:
            //1. ADICIONAR UMA REFERÊNCIA A UM SERVIÇO
            //      WCF (WINDOWS COMMUNICATION FOUNDATION)
            //2. CONSUMIR O SERVIÇO E EXIBIR OS CURSOS DE NÚMERO 1 A 15
        }
    }
}

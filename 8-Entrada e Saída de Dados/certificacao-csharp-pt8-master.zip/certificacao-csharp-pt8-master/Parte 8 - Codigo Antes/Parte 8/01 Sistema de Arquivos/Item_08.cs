﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Listings
{
    class Item_08 //Informações de arquivo
    {
        static void XMain(string[] args)
        {
            //TAREFA:
            //1. Gravar um texto em Arquivo.txt
            //2. Obter informações desse arquivo:
            //      Nome
            //      Caminho completo (diretório + nome do arquivo)
            //      Data e hora do último acesso
            //      Tamanho do arquivo (bytes)
            //      Atributos do arquivo
            //      Adicionar atributo somente-leitura
            //      Verificar os atributos novamente
            //      Remover atributo somente-leitura
            //      Verificar os atributos novamente
        }
    }
}

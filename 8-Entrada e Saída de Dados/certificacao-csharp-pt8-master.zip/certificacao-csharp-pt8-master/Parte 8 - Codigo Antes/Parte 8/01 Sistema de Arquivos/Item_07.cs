﻿using System;
using System.IO;

namespace Listings
{
    class Item_07 //Informações do drive
    {
        static void XMain(string[] args)
        {
            //TAREFA:
            //=======
            //Nome do drive
            //Verificar se o drive está pronto
            //Tipo do drive
            //Formato do drive
            //Espaço livre, em bytes, MB, GB e TB
        }
    }
}

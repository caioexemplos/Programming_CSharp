﻿using System;
using System.IO;
using System.Text;

namespace Listings
{
    class Item_01 //Usando o FileStream
    {
        static void XMain(string[] args)
        {
        }
    }
}
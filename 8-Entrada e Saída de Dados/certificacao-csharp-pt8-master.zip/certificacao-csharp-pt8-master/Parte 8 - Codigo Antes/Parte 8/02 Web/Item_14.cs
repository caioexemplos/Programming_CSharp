﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Listings
{
    class Item_14 //WebClient
    {
        static void XMain(string[] args)
        {
            //TAREFA:
            //Conectar-se site da caelum (http://www.caelum.com.br)
            //apenas para obter e exibir o conteúdo da página do site
            //mas de forma mais simples e rápida
        }
    }
}

﻿using System;

namespace Program03
{
    class Program
    {
        static void Main(string[] args)
        {
            //Desbloquear a IU
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Threading;

namespace Program02
{
    class Program
    {
        static void Main(string[] args)
        {
            //1. Task X Thread

            //2. Thread com expressão lambda

            //3. Passando parâmetro para thread

            //4. Interrompendo um relógio

            //5. Sincronizando uma thread

            //6. Dados da Thread: Nome, cultura, prioridade, contexto, background, pool

            //7. Usando Thread Pool
           
        }
    }
}

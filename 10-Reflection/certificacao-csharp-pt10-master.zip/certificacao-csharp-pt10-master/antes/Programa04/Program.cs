﻿using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Programa04
{
    //Gerar código em tempo de execução usando expressões CodeDom e lambda

    class Program
    {
        static void Main(string[] args)
        {
            //TAREFA: Utilizar código C# para gerar código C#,
            //          produzindo a classe Funcionario:

            /*
            namespace RecursosHumanos
            {
                using system;
                public class Funcionario
                {
                    public string nome;
                    public decimal salario;
                    public Funcionario(string nome, decimal salario)
                    {
                    }
                }
            }
            */

            //Tarefa 1: criar uma unidade de compilação

            //Tarefa 2: criar o namespace RecursosHumanos

            //Tarefa 2.1: importar o namespace System
            //Tarefa 2.2: criar a classe Funcionario
            //Tarefa 2.3: criar o campo nome
            //Tarefa 2.4: criar o campo salário
            //Tarefa 2.5: criar o construtor da classe

            //Tarefa 3: cria o provedor de modelo de código

            //Tarefa 4: gerar código e salva o arquivo
        }
    }
}

﻿using System;

namespace Programa05
{
    class Program
    {
        static void Main(string[] args)
        {
            //TAREFA 1: obter as propriedades de CarrinhoCliente
            //TAREFA 2: descobrir se podem ler ou escrever
            //TAREFA 3: descobrir seus acessadores getters e setters

            Console.ReadLine();
        }
    }
}

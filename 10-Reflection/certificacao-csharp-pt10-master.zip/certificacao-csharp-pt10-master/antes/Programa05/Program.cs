﻿using System;
namespace Programa05
{
    class Program
    {
        static void Main(string[] args)
        {
            //Tarefa 1: obter o nome completo do assembly atual
            //Tarefa 2: obter a versão do assembly atual
            //Tarefa 3: descobrir se o assembly atual 
            //          está no Global Assembly Cache
            //Tarefa 4: descobrir todos os módulos, 
            //          tipos e membros do assembly

            Console.ReadKey();
        }
    }
}



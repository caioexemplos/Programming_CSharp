﻿using System;

namespace _01_01
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}

﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace _01_05
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
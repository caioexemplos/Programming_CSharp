﻿using System;

namespace _01_03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadKey();
        }
    }
}
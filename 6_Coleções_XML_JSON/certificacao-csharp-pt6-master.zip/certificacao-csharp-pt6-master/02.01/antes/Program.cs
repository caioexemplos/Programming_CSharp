﻿using System;

namespace _02._01
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
